import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from openai import OpenAI
import os

# =========================
# OpenAI API 配置
# =========================
client = OpenAI(
    api_key="YOUR_OPENAI_API_KEY"
)

# =========================
# 页面配置
# =========================
st.set_page_config(
    page_title="AI 数据分析 Agent",
    layout="wide"
)

st.title("📊 AI 数据分析与自动报告生成 Agent")

# =========================
# 上传文件
# =========================
uploaded_file = st.file_uploader(
    "上传 CSV 或 Excel 文件",
    type=["csv", "xlsx"]
)

if uploaded_file:

    # =========================
    # 读取数据
    # =========================
    if uploaded_file.name.endswith("csv"):
        df = pd.read_csv(uploaded_file)
    else:
        df = pd.read_excel(uploaded_file)

    st.subheader("原始数据")
    st.dataframe(df)

    # =========================
    # 数据清洗 Agent
    # =========================
    st.subheader("数据清洗")

    before_rows = len(df)
    df = df.drop_duplicates()
    after_rows = len(df)

    missing_values = df.isnull().sum()

    st.write(f"删除重复数据：{before_rows - after_rows} 行")
    st.write("缺失值统计：")
    st.dataframe(missing_values)

    # =========================
    # 数值列识别
    # =========================
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()

    st.subheader("数值字段")
    st.write(numeric_cols)

    # =========================
    # 指标分析 Agent
    # =========================
    st.subheader("关键指标分析")

    analysis_result = {}

    for col in numeric_cols:
        analysis_result[col] = {
            "平均值": round(df[col].mean(), 2),
            "最大值": round(df[col].max(), 2),
            "最小值": round(df[col].min(), 2),
            "总和": round(df[col].sum(), 2),
            "标准差": round(df[col].std(), 2)
        }

    analysis_df = pd.DataFrame(analysis_result).T

    st.dataframe(analysis_df)

    # =========================
    # 异常检测 Agent
    # =========================
    st.subheader("异常检测")

    anomaly_info = {}

    for col in numeric_cols:
        mean = df[col].mean()
        std = df[col].std()

        upper = mean + 2 * std
        lower = mean - 2 * std

        anomalies = df[(df[col] > upper) | (df[col] < lower)]

        anomaly_info[col] = len(anomalies)

    anomaly_df = pd.DataFrame(
        anomaly_info.items(),
        columns=["字段", "异常数量"]
    )

    st.dataframe(anomaly_df)

    # =========================
    # 图表生成 Agent
    # =========================
    st.subheader("数据可视化")

    selected_col = st.selectbox(
        "选择字段生成图表",
        numeric_cols
    )

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df[selected_col])
    ax.set_title(f"{selected_col} 趋势图")
    ax.set_xlabel("Index")
    ax.set_ylabel(selected_col)

    st.pyplot(fig)

    # =========================
    # AI 报告生成 Agent
    # =========================
    st.subheader("AI 自动报告")

    if st.button("生成 AI 分析报告"):

        prompt = f"""
你是一名高级数据分析师。

请根据以下数据分析结果生成一份专业中文业务分析报告。

要求：
1. 总结整体数据情况
2. 分析关键指标
3. 识别潜在异常
4. 给出业务优化建议
5. 使用正式商业语言

分析结果：
{analysis_df.to_string()}

异常检测：
{anomaly_df.to_string()}
"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": "你是一名专业商业数据分析师"
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.3
        )

        report = response.choices[0].message.content

        st.text_area(
            "生成报告",
            report,
            height=400
        )

        os.makedirs("reports", exist_ok=True)

        with open(
            "reports/output_report.txt",
            "w",
            encoding="utf-8"
        ) as f:
            f.write(report)

        st.success("报告已保存到 reports/output_report.txt")

    # =========================
    # QA 问答 Agent
    # =========================
    st.subheader("智能问答")

    user_question = st.text_input(
        "请输入你的问题，例如：哪个指标波动最大？"
    )

    if st.button("开始提问"):

        qa_prompt = f"""
你是一名数据分析助手。

当前数据：
{df.head(20).to_string()}

统计结果：
{analysis_df.to_string()}

用户问题：
{user_question}
"""

        qa_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "user",
                    "content": qa_prompt
                }
            ]
        )

        answer = qa_response.choices[0].message.content

        st.write(answer)
