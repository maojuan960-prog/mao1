
# AI 数据分析与自动报告生成 Agent

## 项目运行方式

### 1. 安装依赖
pip install -r requirements.txt

### 2. 修改 OpenAI Key
在 app.py 中填写：

YOUR_OPENAI_API_KEY

### 3. 启动项目
streamlit run app.py

---

## 项目功能

- 自动读取 CSV / Excel
- 数据清洗
- 指标分析
- 异常检测
- AI 自动生成报告
- 自然语言问答
- 图表可视化

